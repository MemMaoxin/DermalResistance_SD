# nrf5-scheduler-tutorial

This example is intended to be used together with the [nRF5 SDK Scheduler Tutorial](https://devzone.nordicsemi.com/tutorials/b/software-development-kit/posts/scheduler-tutorial).
